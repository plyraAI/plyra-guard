"""Allow ``python -m plyra_guard`` to invoke the CLI."""

from plyra_guard.cli import main

main()
